import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.callbacks import EarlyStopping
import matplotlib.pyplot as plt

# Load sample data from the CSV file
df = pd.read_csv('sample_data.csv')

# Convert date and time to datetime format
df['date'] = pd.to_datetime(df['date'] + ' ' + df['time'])

# Convert date to Unix timestamps
df['date'] = (df['date'] - pd.Timestamp("1970-01-01")) // pd.Timedelta('1s')

# Extract features and target variable
X = df[['date', 'demand_level', 'special_event']]
y = np.full((len(X), 48), 10)  # Base price for parking, create a matrix with the same constant value

# Standardize the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Build the neural network model
model = Sequential()
model.add(Dense(64, activation='relu', input_shape=(X_scaled.shape[1],)))
model.add(Dense(32, activation='relu'))
model.add(Dense(48, activation='linear'))  # Adjust the number of neurons for half-hourly predictions

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

# Use early stopping to prevent overfitting
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

# Train the model
model.fit(X_scaled, y, epochs=100, validation_split=0.2, callbacks=[early_stopping])

# Create a DataFrame with hourly timestamps for a day
hours = pd.date_range('2023-01-01', '2023-01-02', freq='30T')  # 30-minute intervals
half_hourly_data = pd.DataFrame({
    'date': hours,
    'demand_level': 5,  # Adjust this based on the desired demand level
    'special_event': 0  # Adjust this based on the desired special event indicator
})

# Convert date to Unix timestamps for the new data
half_hourly_data['date'] = (half_hourly_data['date'] - pd.Timestamp("1970-01-01")) // pd.Timedelta('1s')

# Standardize the new data
half_hourly_data_scaled = scaler.transform(half_hourly_data[['date', 'demand_level', 'special_event']])

# Make predictions for the half-hourly data
half_hourly_predictions = model.predict(half_hourly_data_scaled)

# Calculate average prices across different intervals for each time of day
average_prices = np.mean(half_hourly_predictions, axis=1)

# Plot individual predictions
plt.figure(figsize=(15, 6))
for i in range(half_hourly_predictions.shape[1]):
    plt.plot(half_hourly_data['date'], half_hourly_predictions[:, i], label=f'Interval {i + 1}', alpha=0.5)

plt.title('Individual Predicted Parking Lot Prices Throughout the Day (Half-Hourly)')
plt.xlabel('Time')
plt.ylabel('Price')
plt.legend()
plt.show()

# Plot average predictions
plt.figure(figsize=(15, 6))
plt.plot(half_hourly_data['date'], average_prices, label='Average Price', linewidth=2, color='black')

plt.title('Average Predicted Parking Lot Prices Throughout the Day (Half-Hourly)')
plt.xlabel('Time')
plt.ylabel('Average Price')
plt.legend()
plt.show()
