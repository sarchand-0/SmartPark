import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Function to generate random data for demand_level and special_event
def generate_random_data():
    demand_level = np.random.uniform(0, 10)
    special_event = np.random.choice([0, 1], p=[0.8, 0.2])  # 80% chance of 0, 20% chance of 1
    return demand_level, special_event

# Generate data for 7 days at 30-minute intervals
start_date = datetime(2023, 1, 1)
end_date = start_date + timedelta(days=6)
time_interval = timedelta(minutes=1)

data = []

current_date = start_date
while current_date <= end_date:
    current_time = datetime(current_date.year, current_date.month, current_date.day, 0, 0, 0)
    for _ in range(48):  # 24 hours * 2 intervals per hour
        demand_level, special_event = generate_random_data()
        current_data = {
            'date': current_date.strftime('%Y-%m-%d'),
            'time': current_time.strftime('%H:%M:%S'),
            'demand_level': demand_level,
            'special_event': special_event
        }
        data.append(current_data)
        current_time += time_interval
    current_date += timedelta(days=1)
# Create a DataFrame from the generated data
df_sample_data = pd.DataFrame(data)
# Save the DataFrame to a CSV file
df_sample_data.to_csv('sample_data.csv', index=False)
