import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.callbacks import EarlyStopping

# Load your CSV file into a DataFrame
df = pd.read_csv('Data.csv')

# Convert date and time to datetime format
df['date'] = pd.to_datetime(df['date'] + ' ' + df['time'])
df = df.drop(['time'], axis=1)

# Convert date to Unix timestamps
df['date'] = (df['date'] - pd.Timestamp("1970-01-01")) // pd.Timedelta('1s')

# Extract features and target variable
X = df[['date', 'demand_level', 'special_event']]
y = df['price']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize the data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Build the neural network model
model = Sequential()
model.add(Dense(64, activation='relu', input_shape=(X_train_scaled.shape[1],)))
model.add(Dense(32, activation='relu'))
model.add(Dense(1, activation='linear'))

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

# Use early stopping to prevent overfitting
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

# Train the model
model.fit(X_train_scaled, y_train, epochs=100, validation_split=0.2, callbacks=[early_stopping])

# Evaluate the model
y_pred = model.predict(X_test_scaled)
mse = mean_squared_error(y_test, y_pred)
print(f'Mean Squared Error: {mse}')

# Now, you can use the trained model to predict parking lot prices for new data
new_data = pd.DataFrame({
    'date': ['2023-01-01 12:00:00'],
    'demand_level': [2],
    'special_event': [1]
})

# Convert date to Unix timestamps for the new data
new_data['date'] = (pd.to_datetime(new_data['date']) - pd.Timestamp("1970-01-01")) // pd.Timedelta('1s')

# Standardize the new data
new_data_scaled = scaler.transform(new_data)

# Make a prediction for the new data
predicted_price = model.predict(new_data_scaled)
print(f'Predicted Price: {predicted_price[0][0]}')
