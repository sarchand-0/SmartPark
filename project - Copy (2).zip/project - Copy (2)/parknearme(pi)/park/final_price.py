import pandas as pd
import numpy as np

# Load demand data from CSV
df = pd.read_csv('sample_data.csv')

# Extract relevant columns
hours = df['time']
demand = df['demand_level']
special_event = df['special_event']

# Set the initial number of parking spaces
initial_spaces = 50

# Set the base price and adjustment values
base_price = 10
price_increase = 1
price_decrease = 1

# Initialize a matrix to store revenue at each time and remaining spaces
num_hours = len(hours)
revenue_matrix = np.zeros((num_hours, initial_spaces + 1))

# Dynamic programming to find optimal pricing decisions
for t in range(num_hours):
    for spaces in range(initial_spaces + 1):
        # Revenue without allocating a parking space
        revenue_no_space = revenue_matrix[t - 1][spaces] if t > 0 else 0

        # Revenue with allocating a parking space
        revenue_with_space = (
            revenue_matrix[t - 1][spaces - 1] + base_price +
            price_increase * demand[t] * (1 + special_event[t])
        ) if t > 0 and spaces > 0 else 0

        # Update the revenue matrix with the maximum revenue
        revenue_matrix[t][spaces] = max(revenue_no_space, revenue_with_space)

# Backtrack to find the optimal pricing decisions
optimal_prices = [base_price] * num_hours
remaining_spaces = initial_spaces
for t in range(num_hours - 1, 0, -1):
    if revenue_matrix[t][remaining_spaces] > revenue_matrix[t - 1][remaining_spaces]:
        optimal_prices[t] += price_increase * (1 + special_event[t])
        remaining_spaces -= 1

# Plot the optimal prices over the day
import matplotlib.pyplot as plt

plt.figure(figsize=(10, 6))
plt.plot(hours, optimal_prices, marker='o')
plt.title('Optimal Prices Over the Day')
plt.xlabel('Time of Day')
plt.ylabel('Price ($)')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()
