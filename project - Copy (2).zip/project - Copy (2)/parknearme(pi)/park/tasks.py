import csv
import random
from datetime import datetime
import time
import pyrebase

config = {
    "apiKey": "AIzaSyDPuKnZ_W7X_NgcoTlGnzTMWI6ujl2rKyg",
    "authDomain": "parking-system-365621.firebaseapp.com",
    "databaseURL": "https://parking-system-365621-default-rtdb.firebaseio.com",
    "projectId": "parking-system-365621",
    "storageBucket": "parking-system-365621.appspot.com",
    "messagingSenderId": "514457351378",
    "appId": "1:514457351378:web:fd8054194b6cacd0d9e90b",
}
firebase = pyrebase.initialize_app(config)
authe = firebase.auth()
database = firebase.database()
array = database.child('occupancy').get().val()
slot = []
state = []
occupied = 0
free = 0
total_space = 0
for i in range(len(array)):
    if array[i]['state'] == "occupied":
        occupied += 1
    else:
        free += 1
    state.append(array[i]['state'])
    slot.append((array[i]['slot']))
    total_space = i + 1
demand=(occupied/total_space)*10
def generate_special_event():
    # Generate a special event with a probability of 1/11
    return 1 if random.randint(1, 11) == 1 else 0





def update_csv_file(filename):
    with open(filename, mode='a', newline='') as file:
        writer = csv.writer(file)
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        demand_level = demand
        special_event = generate_special_event()
        writer.writerow([current_time, demand_level, special_event])


def main():
    filename = "demand_data.csv"

    # Initialize the CSV file with headers if it does not exist
    try:
        with open(filename, mode='x', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["DateTime", "DemandLevel", "SpecialEvent"])
    except FileExistsError:
        pass  # File already exists, no need to initialize

    # Schedule to update the CSV file every minute (for example)
    while True:
        update_csv_file(filename)
        time.sleep(60)  # Wait for 60 seconds before the next update


if __name__ == "__main__":
    main()
